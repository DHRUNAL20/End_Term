import React from 'react'

const About = () => {
  return (
    <div className = 'aboutspace'>
           <h1>OUR MOTIVE IS TO HELP YOU TO GAIN KNOWLEGE SO HERE'S OUR COLLECTION OF FREE BOOKS</h1>
           <h1>WE TIRED OUR BEST TO PROVIDE YOU WITH THE BETTER USER EXPERIENCE THROUGH OUR WEBSITE</h1>
           <h1>THIS IS NOT THE END WE IMPROVE DAY BY DAY TO PROVIDE YOU WITH THE GREAT EXPERIENCE</h1>   
    </div>
  )
}

export default About