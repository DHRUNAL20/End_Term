const booksData = [
    {
        keys : 1,
        srclink  : "https://www.freechildrenstories.com/mr-mckay-the-winter-coat-thief",
        bookname : "MR. MCKAY THE WINTER COAT THIEF",
        imglink  : "https://www.splashlearn.com/blog/wp-content/uploads/2022/01/mr.-mckay.png"

    },
    {
        keys : 2,
        srclink  : "https://www.freechildrenstories.com/guardians-of-lore",
        bookname : "The Guardians of Lore",
        imglink  : "https://www.splashlearn.com/blog/wp-content/uploads/2022/01/guardians-of-bore.png"

    },
    {
        keys : 3,
        srclink  : "https://www.books4yourkids.com/2021/05/fox-chick-sleepover-and-other-stories.html",
        bookname : "Fox + Chick: The Sleepover",
        imglink  : "https://www.splashlearn.com/blog/wp-content/uploads/2022/01/the-sleepover.png"

    },
    {
        keys : 4,
        srclink  : "https://www.freechildrenstories.com/gemma",
        bookname : "Gemma",
        imglink  : "https://www.splashlearn.com/blog/wp-content/uploads/2022/01/gemma.png"

    },
    {
        keys : 5,
        srclink  : "https://jagadgururambhadracharya.org/books/arundhati/",
        bookname : "Arundhatī – अरुन्धती",
        imglink  : "https://rukminim1.flixcart.com/image/416/416/religious-frame/r/h/h/101rampar-khond-original-imaehyq7sxydkt4d.jpeg?q=70"

    },
    {
        keys : 6,
        srclink  : "http://www.magickeys.com/books/gingerbread/index.htmlThe Little Gingerbread Man",
        bookname : "The Little Gingerbread Man",
        imglink  : "https://www.splashlearn.com/blog/wp-content/uploads/2022/01/The-gingerbread-man-1068x1066.jpg"
    },
]

export default booksData;