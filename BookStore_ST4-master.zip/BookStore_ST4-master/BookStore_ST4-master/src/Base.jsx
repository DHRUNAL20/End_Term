import React from "react";

const base = (props) => {
 
    return(
        <>
            <div className="base">
                <span> {props.bookname} </span>    
            </div>
        </>
    );
}
export default base;
