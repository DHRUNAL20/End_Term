import React from 'react'

const Contact = () => {
  return (
    <div className = 'aboutspace'>
          <h1>PHONE NO - 123XXXXXXXX ----------------</h1>
          <br/>
          <h1>EMAIL ID - DJ@gmail.com ---------------</h1>
          <br/><br/>
          <from className="fm">
            <input type ='text' placeholder='enter your name'/>
            <br/>
            <input type ='email' placeholder='enter your mail'/>
            <br/>
            <input type ='text' placeholder='enter your country'/>
            <br/>
            <input type ='text' placeholder='enter some message'/>
            <br/>
            <button type='submit'>submit</button>
          </from>
          <br/>
          <br/>
          <h1>THANK U</h1>
         
        
    </div>
  )
}

export default Contact